import java.util.Scanner;


public abstract class BasePin {
    private String NoRef;

    BasePin(String NoRef){
        this.NoRef = NoRef;
    }

    BasePin(){
        Scanner input = new Scanner(System.in);
        System.out.print("Masukkan no referensi : ");
        this.NoRef = input.nextLine();
    }

    public String getNoRef() {
        return NoRef;
    }

    public void setNoRef(String noRef) {
        NoRef = noRef;
    }

    abstract void info();
    

}
