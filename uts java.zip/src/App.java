public class App {
    public static void main(String[] args) throws Exception {
        Pembayaran pembayaran = new Pembayaran();
        pembayaran.struk();
    }
}
