
public interface Cetak {
    void struk() throws Exception;

    
} 