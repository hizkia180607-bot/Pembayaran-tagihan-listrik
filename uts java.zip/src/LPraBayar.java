import java.util.Scanner;

public class LPraBayar extends BasePin {
    private float NomToken;
    private String StroomToken;

    LPraBayar(String NoRef, float NomToken, String StroomToken){
        super(NoRef);
        this.NomToken = NomToken; 
        this.StroomToken = StroomToken;
    }

    LPraBayar(){
        super();
        Scanner input = new Scanner(System.in);
        System.out.print("Masukkan nomor token : ");
        this.NomToken = input.nextFloat();
        input.nextLine();
        System.out.print("Masukkan stroom token : ");
        this.StroomToken = input.nextLine();
    }

    public float getNomToken() {
        return NomToken;
    }
    public void setNomToken(float nomToken) {
        NomToken = nomToken;
    }
    public String getStroomToken() {
        return StroomToken;
    }
    public void setStroomToken(String stroomToken) {
        StroomToken = stroomToken;
    }

    @Override
    void info(){
        System.out.println("Jenis tagihan anda adalah Prabayar");
    }
    
}
